import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../core/services/cart.service';
import { OrderService } from '../../core/services/order.service';
import { AuthService } from '../../core/services/auth.service';
import { CartItem } from '../../core/models/cart-item.model';
import { CreateOrderPayload } from '../../core/models/order.model';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, LoadingSpinnerComponent],
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
})
export class CartComponent implements OnInit {
  items: CartItem[] = [];
  isLoading = true;
  isPlacingOrder = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private cartService: CartService,
    private orderService: OrderService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    if (!this.authService.isLoggedIn()) {
      this.isLoading = false;
      return;
    }
    this.loadCart();
  }

  loadCart(): void {
    this.isLoading = true;
    this.cartService.getCart().subscribe({
      next: (items) => {
        this.items = items;
        this.isLoading = false;
      },
      error: (err: Error) => {
        this.errorMessage = err.message;
        this.isLoading = false;
      },
    });
  }

  /** Template-driven: called on (change) of the quantity input */
  onQuantityChange(item: CartItem): void {
    const qty = Number(item.quantity);
    if (isNaN(qty) || qty < 1) {
      item.quantity = 1;
    } else if (qty > item.stock) {
      item.quantity = item.stock;
    }

    this.cartService.updateQuantity(item.id, item.quantity).subscribe({
      error: () => {
        this.errorMessage = 'Failed to update quantity.';
      },
    });
  }

  removeItem(item: CartItem): void {
    this.cartService.removeFromCart(item.id).subscribe({
      next: () => {
        this.items = this.items.filter((i) => i.id !== item.id);
      },
      error: () => {
        this.errorMessage = 'Failed to remove item.';
      },
    });
  }

  getSubtotal(): number {
    return this.items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  }

  getShipping(): number {
    return this.getSubtotal() > 100 ? 0 : 9.99;
  }

  getTotal(): number {
    return this.getSubtotal() + this.getShipping();
  }

  placeOrder(): void {
    if (this.items.length === 0) return;

    this.isPlacingOrder = true;
    this.errorMessage = '';
    this.successMessage = '';

    const payload: CreateOrderPayload = {
      userId: this.authService.getUserId()!,
      items: this.items.map((i) => ({
        productId: i.productId,
        name: i.name,
        price: i.price,
        quantity: i.quantity,
        image: i.image,
      })),
      total: this.getTotal(),
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    this.orderService.placeOrder(payload).subscribe({
      next: () => {
        this.cartService.clearCart(this.items).subscribe({
          next: () => {
            this.items = [];
            this.isPlacingOrder = false;
            this.successMessage =
              '🎉 Order placed successfully! Check your orders page.';
          },
        });
      },
      error: (err: Error) => {
        this.errorMessage = err.message;
        this.isPlacingOrder = false;
      },
    });
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  trackById(_: number, item: CartItem): string {
    return item.id;
  }
}
