import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../../core/services/product.service';
import { CartService } from '../../../core/services/cart.service';
import { AuthService } from '../../../core/services/auth.service';
import { Product } from '../../../core/models';
import { LoadingSpinnerComponent } from '../../../shared/components/loading-spinner/loading-spinner.component';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, LoadingSpinnerComponent],
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss'],
})
export class ProductDetailComponent implements OnInit {
  product: Product | null = null;
  quantity = 1;
  isLoading = true;
  errorMessage = '';
  isAddingToCart = false;
  addedSuccess = false;

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private cartService: CartService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) {
      this.errorMessage = 'Product not found.';
      this.isLoading = false;
      return;
    }

    this.productService.getProductById(id).subscribe({
      next: (product) => {
        this.product = product;
        this.isLoading = false;
      },
      error: (err: Error) => {
        this.errorMessage = err.message;
        this.isLoading = false;
      },
    });
  }

  decreaseQty(): void {
    if (this.quantity > 1) this.quantity--;
  }

  increaseQty(): void {
    if (this.product && this.quantity < this.product.stock) this.quantity++;
  }

  addToCart(): void {
    if (!this.product || !this.authService.isLoggedIn()) return;
    const userId = this.authService.getUserId()!;

    this.isAddingToCart = true;

    this.cartService
      .addToCart({
        userId,
        productId: this.product.id,
        name: this.product.name,
        price: this.product.price,
        image: this.product.image,
        quantity: this.quantity,
        stock: this.product.stock,
      })
      .subscribe({
        next: () => {
          this.isAddingToCart = false;
          this.addedSuccess = true;
          setTimeout(() => (this.addedSuccess = false), 3000);
        },
        error: () => {
          this.isAddingToCart = false;
        },
      });
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  getStars(): number[] {
    return Array.from({ length: 5 }, (_, i) => i + 1);
  }
}
