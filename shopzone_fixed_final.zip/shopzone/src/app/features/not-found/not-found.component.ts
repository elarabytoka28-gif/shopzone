import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="not-found">
      <div class="nf-inner fade-in-scale">
        <span class="nf-code">404</span>
        <h1 class="nf-title">Page not found</h1>
        <p class="nf-desc">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div class="nf-actions">
          <a routerLink="/products" class="btn btn-primary btn-lg">Browse products</a>
          <a routerLink="/" class="btn btn-secondary btn-lg">Go home</a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .not-found {
      min-height: calc(100vh - var(--navbar-height));
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      background:
        radial-gradient(ellipse 50% 50% at 50% 50%, rgba(212, 168, 83, 0.04) 0%, transparent 70%),
        var(--color-bg);
    }

    .nf-inner {
      text-align: center;
      max-width: 480px;
    }

    .nf-code {
      font-family: var(--font-display);
      font-size: clamp(5rem, 18vw, 9rem);
      font-weight: 700;
      color: var(--color-border);
      line-height: 1;
      display: block;
      letter-spacing: -0.04em;
    }

    .nf-title {
      font-family: var(--font-display);
      font-size: 2rem;
      font-weight: 600;
      color: var(--color-text);
      margin: 1rem 0 0.75rem;
    }

    .nf-desc {
      color: var(--color-text-secondary);
      font-weight: 300;
      font-size: 1.0625rem;
      margin-bottom: 2rem;
    }

    .nf-actions {
      display: flex;
      gap: 0.875rem;
      justify-content: center;
      flex-wrap: wrap;
    }
  `],
})
export class NotFoundComponent {}
