import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductService } from '../../core/services/product.service';
import { Product } from '../../core/models';
import { LoadingSpinnerComponent } from '../../shared/components/loading-spinner/loading-spinner.component';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterLink, LoadingSpinnerComponent],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.scss',
})
export class LandingComponent implements OnInit {
  featuredProducts: Product[] = [];
  loading = true;

  stats = [
    { num: '10K+', label: 'Happy Customers' },
    { num: '500+', label: 'Products' },
    { num: '4.9★', label: 'Average Rating' },
    { num: '24/7', label: 'Support' },
  ];

  categories = [
    { icon: '💻', name: 'Electronics', count: '120+ items' },
    { icon: '👗', name: 'Fashion', count: '85+ items' },
    { icon: '🏠', name: 'Furniture', count: '60+ items' },
    { icon: '🏋️', name: 'Sports', count: '95+ items' },
    { icon: '📚', name: 'Books', count: '200+ items' },
    { icon: '🎮', name: 'Gaming', count: '75+ items' },
  ];

  features = [
    {
      icon: '🚀',
      title: 'Fast Delivery',
      desc: 'Get your orders delivered to your doorstep within 2–3 business days, guaranteed.',
    },
    {
      icon: '🔒',
      title: 'Secure Payments',
      desc: 'Your financial data is protected with bank-level SSL encryption on every transaction.',
    },
    {
      icon: '↩️',
      title: 'Easy Returns',
      desc: 'Not satisfied? Return any product within 30 days for a full, hassle-free refund.',
    },
    {
      icon: '🎧',
      title: '24/7 Support',
      desc: 'Our dedicated support team is always here to help you with any questions or issues.',
    },
  ];

  testimonials = [
    {
      text: 'ShopZone has completely changed how I shop online. The products are top-notch and delivery is always on time.',
      name: 'Sarah M.',
      role: 'Verified Customer',
    },
    {
      text: 'I love the curated selection. Found things I never knew I needed — and the checkout is super smooth.',
      name: 'James K.',
      role: 'Verified Customer',
    },
    {
      text: 'Customer support was incredibly helpful when I needed to return an item. 5 stars without hesitation.',
      name: 'Leila A.',
      role: 'Verified Customer',
    },
  ];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe({
      next: (products) => {
        this.featuredProducts = products.slice(0, 4);
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      },
    });
  }
}
