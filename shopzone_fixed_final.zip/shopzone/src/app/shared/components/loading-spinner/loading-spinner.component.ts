import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-loading-spinner',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="spinner-wrap" [class.full]="fullPage">
      <div class="spinner" [style.width.px]="size" [style.height.px]="size"></div>
      <p class="spinner-label" *ngIf="label">{{ label }}</p>
    </div>
  `,
  styles: [`
    .spinner-wrap {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      padding: 3rem;

      &.full {
        min-height: 50vh;
      }
    }

    .spinner {
      border: 2px solid var(--color-border);
      border-top-color: var(--color-accent);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    .spinner-label {
      font-size: 0.875rem;
      color: var(--color-text-muted);
    }
  `],
})
export class LoadingSpinnerComponent {
  @Input() size = 36;
  @Input() label = '';
  @Input() fullPage = false;
}
