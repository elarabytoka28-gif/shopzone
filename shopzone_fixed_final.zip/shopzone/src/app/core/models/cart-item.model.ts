export interface CartItem {
  id: string;
  userId: string;
  productId: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
  stock: number;
}
