import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  BehaviorSubject,
  Observable,
  tap,
  catchError,
  throwError,
  switchMap,
  of,
} from 'rxjs';
import { CartItem } from '../models';
import { AuthService } from './auth.service';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private readonly apiUrl = `${environment.apiUrl}/cart`;

  private cartCountSubject = new BehaviorSubject<number>(0);
  cartCount$ = this.cartCountSubject.asObservable();

  constructor(private http: HttpClient, private authService: AuthService) {
    if (this.authService.isLoggedIn()) {
      this.refreshCartCount();
    }
  }

  getCart(): Observable<CartItem[]> {
    const userId = this.authService.getUserId();
    return this.http
      .get<CartItem[]>(`${this.apiUrl}?userId=${userId}`)
      .pipe(
        tap((items) => this.cartCountSubject.next(items.length)),
        catchError(() =>
          throwError(() => new Error('Failed to load cart.'))
        )
      );
  }

  addToCart(item: Omit<CartItem, 'id'>): Observable<CartItem> {
    const userId = this.authService.getUserId();
    // Check if item already exists
    return this.http
      .get<CartItem[]>(`${this.apiUrl}?userId=${userId}&productId=${item.productId}`)
      .pipe(
        switchMap((existing) => {
          if (existing.length > 0) {
            const current = existing[0];
            const newQty = Math.min(current.quantity + item.quantity, item.stock);
            return this.http.patch<CartItem>(`${this.apiUrl}/${current.id}`, {
              quantity: newQty,
            });
          }
          return this.http.post<CartItem>(this.apiUrl, item);
        }),
        tap(() => this.refreshCartCount()),
        catchError(() =>
          throwError(() => new Error('Failed to add item to cart.'))
        )
      );
  }

  updateQuantity(itemId: string, quantity: number): Observable<CartItem> {
    return this.http
      .patch<CartItem>(`${this.apiUrl}/${itemId}`, { quantity })
      .pipe(
        catchError(() =>
          throwError(() => new Error('Failed to update quantity.'))
        )
      );
  }

  removeFromCart(itemId: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${itemId}`).pipe(
      tap(() => this.refreshCartCount()),
      catchError(() =>
        throwError(() => new Error('Failed to remove item.'))
      )
    );
  }

  clearCart(items: CartItem[]): Observable<void[]> {
    const deletions = items.map((item) =>
      this.http.delete<void>(`${this.apiUrl}/${item.id}`)
    );
    return new Observable((observer) => {
      Promise.all(deletions.map((d) => d.toPromise()))
        .then(() => {
          this.cartCountSubject.next(0);
          observer.next([]);
          observer.complete();
        })
        .catch((err) => observer.error(err));
    });
  }

  refreshCartCount(): void {
    const userId = this.authService.getUserId();
    if (!userId) {
      this.cartCountSubject.next(0);
      return;
    }
    this.http
      .get<CartItem[]>(`${this.apiUrl}?userId=${userId}`)
      .subscribe({
        next: (items) => this.cartCountSubject.next(items.length),
        error: () => this.cartCountSubject.next(0),
      });
  }

  resetCount(): void {
    this.cartCountSubject.next(0);
  }
}
