import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap, map, catchError, throwError } from 'rxjs';
import { User, LoginCredentials, RegisterPayload } from '../models';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly apiUrl = environment.apiUrl;
  private readonly USER_ID_KEY = 'userId';
  private readonly CURRENT_USER_KEY = 'currentUser';

  constructor(private http: HttpClient, private router: Router) {}

  login(credentials: LoginCredentials): Observable<User> {
    const { email, password } = credentials;
    return this.http
      .get<User[]>(`${this.apiUrl}/users?email=${email}&password=${password}`)
      .pipe(
        map((users) => {
          if (!users || users.length === 0) {
            throw new Error('Invalid email or password.');
          }
          return users[0];
        }),
        tap((user: User) => {
          localStorage.setItem(this.USER_ID_KEY, user.id);
          localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(user));
        }),
        catchError((err) =>
          throwError(() => new Error(err.message || 'Login failed.'))
        )
      );
  }

  register(payload: RegisterPayload): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/users`, payload).pipe(
      tap((user: User) => {
        localStorage.setItem(this.USER_ID_KEY, user.id);
        localStorage.setItem(this.CURRENT_USER_KEY, JSON.stringify(user));
      }),
      catchError(() =>
        throwError(() => new Error('Registration failed. Please try again.'))
      )
    );
  }

  logout(): void {
    localStorage.removeItem(this.USER_ID_KEY);
    localStorage.removeItem(this.CURRENT_USER_KEY);
    this.router.navigate(['/login']);
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem(this.USER_ID_KEY);
  }

  getCurrentUser(): User | null {
    const raw = localStorage.getItem(this.CURRENT_USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  }

  getUserId(): string | null {
    return localStorage.getItem(this.USER_ID_KEY);
  }
}
