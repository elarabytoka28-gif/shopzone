import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { Order, CreateOrderPayload } from '../models';
import { AuthService } from './auth.service';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private readonly apiUrl = `${environment.apiUrl}/orders`;

  constructor(private http: HttpClient, private authService: AuthService) {}

  getOrders(): Observable<Order[]> {
    const userId = this.authService.getUserId();
    return this.http
      .get<Order[]>(`${this.apiUrl}?userId=${userId}`)
      .pipe(
        catchError(() =>
          throwError(() => new Error('Failed to load orders.'))
        )
      );
  }

  placeOrder(payload: CreateOrderPayload): Observable<Order> {
    return this.http.post<Order>(this.apiUrl, payload).pipe(
      catchError(() =>
        throwError(() => new Error('Failed to place order.'))
      )
    );
  }
}
